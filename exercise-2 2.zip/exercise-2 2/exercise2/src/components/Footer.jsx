function Footer() {
    return (
      <footer className="block">
        <p>© 2025 React Learning. All Rights Reserved.</p>
      </footer>
    );
  }
  
  export default Footer;  